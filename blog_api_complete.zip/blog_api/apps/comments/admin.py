from django.contrib import admin
from .models import Comment


@admin.register(Comment)
class CommentAdmin(admin.ModelAdmin):
    list_display = ['author', 'post', 'parent', 'created_at']
    list_filter = ['created_at']
    search_fields = ['author__email', 'body']
    readonly_fields = ['created_at', 'updated_at']
