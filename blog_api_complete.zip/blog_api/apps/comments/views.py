from rest_framework import generics, permissions
from rest_framework.exceptions import NotFound
from .models import Comment
from .serializers import CommentSerializer
from apps.posts.models import Post
from core.permissions import IsOwnerOrReadOnly


def get_post_or_404(slug):
    try:
        return Post.objects.get(slug=slug)
    except Post.DoesNotExist:
        raise NotFound(f"Post '{slug}' not found.")


class CommentListCreateView(generics.ListCreateAPIView):
    """
    GET  /api/posts/{slug}/comments/  -> list all top-level comments (with nested replies)
    POST /api/posts/{slug}/comments/  -> add a comment or reply
    """
    serializer_class = CommentSerializer

    def get_queryset(self):
        post = get_post_or_404(self.kwargs['slug'])
        return Comment.objects.filter(
            post=post, parent=None
        ).select_related('author').prefetch_related('replies__author')

    def perform_create(self, serializer):
        post = get_post_or_404(self.kwargs['slug'])
        serializer.save(author=self.request.user, post=post)


class CommentDetailView(generics.RetrieveUpdateDestroyAPIView):
    """
    GET    /api/posts/{slug}/comments/{id}/
    PATCH  /api/posts/{slug}/comments/{id}/  -> edit own comment
    DELETE /api/posts/{slug}/comments/{id}/  -> delete own comment
    """
    serializer_class = CommentSerializer
    permission_classes = [permissions.IsAuthenticatedOrReadOnly, IsOwnerOrReadOnly]
    queryset = Comment.objects.all()
    http_method_names = ['get', 'patch', 'delete', 'head', 'options']
