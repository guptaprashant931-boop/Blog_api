from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework.exceptions import NotFound
from apps.posts.models import Post
from apps.posts.serializers import PostListSerializer
from .models import Like, Bookmark


def get_post_or_404(slug):
    try:
        return Post.objects.get(slug=slug)
    except Post.DoesNotExist:
        raise NotFound(f"Post '{slug}' not found.")


class LikeToggleView(APIView):
    """
    POST /api/posts/{slug}/like/
    Toggles like: likes if not liked, unlikes if already liked.
    Uses get_or_create for atomic, race-condition-safe toggle.
    """
    permission_classes = [IsAuthenticated]

    def post(self, request, slug):
        post = get_post_or_404(slug)
        like, created = Like.objects.get_or_create(user=request.user, post=post)

        if not created:
            # Already liked — remove the like
            like.delete()
            return Response({
                'liked': False,
                'like_count': post.like_count,
                'message': 'Post unliked.'
            })

        return Response({
            'liked': True,
            'like_count': post.like_count,
            'message': 'Post liked.'
        })


class BookmarkToggleView(APIView):
    """
    POST /api/posts/{slug}/bookmark/
    Toggles bookmark: bookmarks if not bookmarked, removes if already bookmarked.
    """
    permission_classes = [IsAuthenticated]

    def post(self, request, slug):
        post = get_post_or_404(slug)
        bookmark, created = Bookmark.objects.get_or_create(user=request.user, post=post)

        if not created:
            bookmark.delete()
            return Response({
                'bookmarked': False,
                'message': 'Bookmark removed.'
            })

        return Response({
            'bookmarked': True,
            'message': 'Post bookmarked.'
        })


class MyBookmarksView(APIView):
    """
    GET /api/users/me/bookmarks/
    Returns all posts bookmarked by the current user.
    """
    permission_classes = [IsAuthenticated]

    def get(self, request):
        bookmarked_posts = Post.objects.filter(
            bookmarks__user=request.user
        ).select_related('author', 'category').prefetch_related('tags')
        serializer = PostListSerializer(bookmarked_posts, many=True)
        return Response(serializer.data)
