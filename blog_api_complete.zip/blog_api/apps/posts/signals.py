from django.db.models.signals import pre_save
from django.dispatch import receiver
from django.utils import timezone
from .models import Post
from core.utils import unique_slug


@receiver(pre_save, sender=Post)
def set_slug_and_published_at(sender, instance, **kwargs):
    """
    Automatically:
    1. Generates a slug from the title if not already set.
    2. Sets published_at when status changes to 'published'.
    """
    if not instance.slug:
        instance.slug = unique_slug(Post, instance.title)

    if instance.status == Post.Status.PUBLISHED and not instance.published_at:
        instance.published_at = timezone.now()
